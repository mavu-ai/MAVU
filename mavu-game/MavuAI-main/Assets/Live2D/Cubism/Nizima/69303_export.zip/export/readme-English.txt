
-----------------------------------------------
-----------------------------------------------

Thank you for purchasing the model.
If you find any problems with the model, please contact us.
Please use the contact function on the sales website or email us here�ipanda.commission2@gmail.com�j.

-----------------------------------------------
About Tracking
�EPlease adjust each value in VTube studio to suit your needs.
As exceptions, "��Auto Breath" should be left at their default settings.
�EThe numbers that appear in the description below are about OUT.
�EDo not use auto-setup.
�EItems that operate in a general manner are omitted from the explanation.

�EItems marked with a star are for changing costumes and hairstyles.
Please refer to the instructions below for more information about this.
https://panda-mfmf.fanbox.cc/posts/5375789

�EItems marked with a black circle can be deleted.
If you do not want the relevant movement, delete it.


�EBrow Form Right�ABrow Form Left
Eyebrows change to a troubled shape.
Angry eyebrows can be changed by using keystrokes.

�ESmileEye
Raising the corners of the mouth makes the eyes smile.
�iSmileEye=0.9�`1�j

�Econtracion eye
Raising the eyebrows makes the black eyes smaller.
�icontracion eye=0.9�`1�j

�EFaceAngry
This movement is limited to iPhone. For webcams, please use keystrokes to change it.
When it comes to 1, the face looks like ><.

�Esad-looking mouth
When the eyebrows are down, the mouth looks sad.
(below -0.5 and it will look sad)
Adjust the eyebrows so that they respond only to large brow movements.
It may be difficult without an iPhone because of the need for fine-tuning.

�EWing movement
The deformation of the eyebrows causes the wings to move.
If -0.5 or less, the wings move downward; if 0.9 or more, the wings move slightly upward.

�Emouth X1
The mouth moves left and right.
�Emouth X2
When the mouth is moved sideways, the eyes move in tandem.

�Echeek
When he smiles, his cheeks turn a little red
�iAt 0.9 or higher�j


-----------------------------------------------
Differential facial expressions by key operation

Some expressions are not intended to be used together.
Please reset them each time when you no longer need to change the expressions.
Press the same key again or press the Reset button to erase it.
If key operations are performed consecutively without resetting, the expression may not be changed correctly.

For motion, please wait until playback is finished.

The key settings can be changed in vtube studio.
Change the corresponding keys or delete the items you do not need.

z/eyes without light
x/sparkling eyes
c/spiral eyes
v/face Angry����
b/raise both hands
n/Have a controller
a/sad-looking mouth
s/Sweat
d/Tears
f/turn pale
g/Waving motion
h/Eyebrows in an angry
r/reset
